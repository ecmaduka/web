<?php
/*==============================================
  BARRIE BRAIDS SALON - TWILIO WHATSAPP HANDLER
  Sends booking requests directly to your WhatsApp
==============================================*/

// Twilio PHP SDK
require_once __DIR__ . '/twilio-php/src/Twilio/autoload.php';
use Twilio\Rest\Client;

// Error handling
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/booking_errors.log');

/*==============================================
  ⚠️ CONFIGURATION - ONLY CHANGE LINE 20!
==============================================*/

// Your Twilio credentials
define('TWILIO_ACCOUNT_SID', 'AC01fb37fe0bba7739a1f9b2188fde874c');
define('TWILIO_AUTH_TOKEN', 'ec2e6be1405a3e0c7a6eebea71210407'); // ← PUT YOUR AUTH TOKEN HERE (LINE 20)

// Twilio WhatsApp sandbox number (don't change)
define('TWILIO_WHATSAPP_FROM', 'whatsapp:+14155238886');

// Your WhatsApp number (where you'll receive bookings)
define('YOUR_WHATSAPP_NUMBER', 'whatsapp:+14376638103');

// Rate limiting
define('MAX_SUBMISSIONS_PER_HOUR', 10);

/*==============================================
  SECURITY HEADERS
==============================================*/
header('Content-Type: application/json');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('X-XSS-Protection: 1; mode=block');

/*==============================================
  RATE LIMITING FUNCTION
==============================================*/
function checkRateLimit() {
    $ip = $_SERVER['REMOTE_ADDR'];
    $file = sys_get_temp_dir() . '/rate_limit_' . md5($ip) . '.txt';
    
    if (file_exists($file)) {
        $submissions = file_get_contents($file);
        $submissions = explode("\n", trim($submissions));
        $submissions = array_filter($submissions, function($time) {
            return (time() - intval($time)) < 3600;
        });
        file_put_contents($file, implode("\n", $submissions));
    } else {
        $submissions = [];
    }
    
    if (count($submissions) >= MAX_SUBMISSIONS_PER_HOUR) {
        return false;
    }
    
    file_put_contents($file, time() . "\n", FILE_APPEND);
    return true;
}

/*==============================================
  INPUT SANITIZATION
==============================================*/
function sanitize($input) {
    if (is_array($input)) {
        foreach ($input as $key => $value) {
            $input[$key] = sanitize($value);
        }
        return $input;
    }
    
    $input = trim($input);
    $input = stripslashes($input);
    $input = htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
    return $input;
}

/*==============================================
  VALIDATION FUNCTIONS
==============================================*/
function validateName($name) {
    return strlen($name) >= 2 && strlen($name) <= 100;
}

function validatePhone($phone) {
    $digits = preg_replace('/\D/', '', $phone);
    return strlen($digits) >= 10 && strlen($digits) <= 11;
}

function validateEmail($email) {
    if (empty($email)) return true;
    return filter_var($email, FILTER_VALIDATE_EMAIL) && strlen($email) <= 100;
}

function validateDate($date) {
    $d = DateTime::createFromFormat('Y-m-d', $date);
    return $d && $d->format('Y-m-d') === $date;
}

/*==============================================
  MAIN PROCESSING
==============================================*/

// Only accept POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

// Rate limiting check
if (!checkRateLimit()) {
    http_response_code(429);
    echo json_encode(['success' => false, 'message' => 'Too many submissions. Please wait and try again.']);
    exit;
}

// Get and sanitize form data
$name = sanitize($_POST['name'] ?? '');
$phone = sanitize($_POST['phone'] ?? '');
$email = sanitize($_POST['email'] ?? '');
$service = sanitize($_POST['service'] ?? '');
$date = sanitize($_POST['date'] ?? '');
$time = sanitize($_POST['time'] ?? '');
$notes = sanitize($_POST['notes'] ?? '');

// Validation
$errors = [];

if (empty($name) || !validateName($name)) {
    $errors[] = 'Invalid name';
}

if (empty($phone) || !validatePhone($phone)) {
    $errors[] = 'Invalid phone number';
}

if (!validateEmail($email)) {
    $errors[] = 'Invalid email address';
}

if (empty($service)) {
    $errors[] = 'Service selection required';
}

if (empty($date) || !validateDate($date)) {
    $errors[] = 'Invalid date';
}

if (empty($time)) {
    $errors[] = 'Time selection required';
}

if (strlen($notes) > 500) {
    $errors[] = 'Notes too long (max 500 characters)';
}

// Return validation errors
if (!empty($errors)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => implode(', ', $errors)]);
    exit;
}

/*==============================================
  HONEYPOT SPAM CHECK
==============================================*/
if (!empty($_POST['website'])) {
    error_log('Spam detected from IP: ' . $_SERVER['REMOTE_ADDR']);
    echo json_encode(['success' => true, 'message' => 'Thank you for your submission']);
    exit;
}

/*==============================================
  FORMAT WHATSAPP MESSAGE
==============================================*/
$whatsappMessage = "🎉 *NEW BOOKING REQUEST*\n\n";
$whatsappMessage .= "👤 *Customer Information:*\n";
$whatsappMessage .= "Name: *{$name}*\n";
$whatsappMessage .= "Phone: {$phone}\n";
$whatsappMessage .= "Email: " . ($email ?: 'Not provided') . "\n\n";
$whatsappMessage .= "💇‍♀️ *Booking Details:*\n";
$whatsappMessage .= "Service: *{$service}*\n";
$whatsappMessage .= "Date: {$date}\n";
$whatsappMessage .= "Time: {$time}\n\n";

if (!empty($notes)) {
    $whatsappMessage .= "📝 *Additional Notes:*\n";
    $whatsappMessage .= "{$notes}\n\n";
}

$whatsappMessage .= "────────────────────\n";
$whatsappMessage .= "📍 Barrie Braids Salon\n";
$whatsappMessage .= "🌐 Submitted via website\n";
$whatsappMessage .= "⏰ " . date('Y-m-d H:i:s');

/*==============================================
  SEND TO WHATSAPP VIA TWILIO
==============================================*/
try {
    // Create Twilio client
    $twilio = new Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN);
    
    // Send WhatsApp message
    $message = $twilio->messages->create(
        YOUR_WHATSAPP_NUMBER,
        [
            'from' => TWILIO_WHATSAPP_FROM,
            'body' => $whatsappMessage
        ]
    );
    
    // Success response
    http_response_code(200);
    echo json_encode([
        'success' => true,
        'message' => 'Thank you! Your booking request has been received. We\'ll contact you shortly.'
    ]);
    
    // Log success
    error_log("Booking sent successfully from {$name} ({$phone}) - Message SID: {$message->sid}");
    
} catch (Exception $e) {
    // Error sending to WhatsApp
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Unable to send booking request. Please call us at (705) 881-3082.'
    ]);
    
    // Log detailed error
    error_log("Twilio error: " . $e->getMessage());
}

?>
