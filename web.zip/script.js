/*==============================================
  BARRIE BRAIDS SALON - MODERN JAVASCRIPT
  Interactive Features & Enhancements
==============================================*/

/*==============================================
  SECURITY: FORCE HTTPS
==============================================*/
if (location.protocol !== 'https:' && location.hostname !== 'localhost' && location.hostname !== '127.0.0.1') {
    location.replace(`https:${location.href.substring(location.protocol.length)}`);
}

/*==============================================
  SECURITY: CSRF TOKEN GENERATION
==============================================*/
function generateCSRFToken() {
    const array = new Uint8Array(32);
    crypto.getRandomValues(array);
    return Array.from(array, byte => byte.toString(16).padStart(2, '0')).join('');
}

/*==============================================
  SECURITY: INPUT SANITIZATION
==============================================*/
function sanitizeInput(str) {
    if (!str) return '';
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
}

document.addEventListener('DOMContentLoaded', function() {
    
    /*==============================================
      SECURITY: INITIALIZE CSRF TOKEN
    ==============================================*/
    const csrfTokenField = document.getElementById('csrf_token');
    if (csrfTokenField) {
        const token = generateCSRFToken();
        csrfTokenField.value = token;
        sessionStorage.setItem('csrf_token', token);
    }
    
    /*==============================================
      MOBILE MENU TOGGLE
    ==============================================*/
    const hamburger = document.getElementById('hamburger');
    const mobileOverlay = document.getElementById('mobileOverlay');
    const closeMenu = document.getElementById('closeMenu');
    const mobileLinks = document.querySelectorAll('.mobile-link');
    
    // Open mobile menu
    if (hamburger) {
        hamburger.addEventListener('click', function() {
            mobileOverlay.classList.add('active');
            hamburger.classList.add('active');
            document.body.style.overflow = 'hidden';
        });
    }
    
    // Close mobile menu
    function closeMobileMenu() {
        mobileOverlay.classList.remove('active');
        hamburger.classList.remove('active');
        document.body.style.overflow = '';
    }
    
    if (closeMenu) {
        closeMenu.addEventListener('click', closeMobileMenu);
    }
    
    // Close on link click
    mobileLinks.forEach(link => {
        link.addEventListener('click', closeMobileMenu);
    });
    
    // Close on escape key
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && mobileOverlay.classList.contains('active')) {
            closeMobileMenu();
        }
    });
    
    /*==============================================
      STICKY HEADER ON SCROLL
    ==============================================*/
    const header = document.getElementById('header');
    let lastScroll = 0;
    
    window.addEventListener('scroll', function() {
        const currentScroll = window.pageYOffset;
        
        if (currentScroll > 50) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
        
        lastScroll = currentScroll;
    });
    
    /*==============================================
      SMOOTH SCROLL FOR ANCHOR LINKS
    ==============================================*/
    const anchors = document.querySelectorAll('a[href^="#"]');
    
    anchors.forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            const href = this.getAttribute('href');
            
            if (href === '#') return;
            
            const target = document.querySelector(href);
            
            if (target) {
                e.preventDefault();
                
                const headerHeight = header.offsetHeight;
                const targetPosition = target.offsetTop - headerHeight;
                
                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });
    
    /*==============================================
      GALLERY FILTER
    ==============================================*/
    const filterButtons = document.querySelectorAll('.filter-btn');
    const galleryItems = document.querySelectorAll('.gallery-item');
    
    filterButtons.forEach(button => {
        button.addEventListener('click', function() {
            const filter = this.getAttribute('data-filter');
            
            // Update active button
            filterButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            
            // Filter items
            galleryItems.forEach(item => {
                const category = item.getAttribute('data-category');
                
                if (filter === 'all' || category === filter) {
                    item.style.display = 'block';
                    setTimeout(() => {
                        item.style.opacity = '1';
                        item.style.transform = 'scale(1)';
                    }, 10);
                } else {
                    item.style.opacity = '0';
                    item.style.transform = 'scale(0.8)';
                    setTimeout(() => {
                        item.style.display = 'none';
                    }, 300);
                }
            });
        });
    });
    
    /*==============================================
      FAQ ACCORDION
    ==============================================*/
    const faqItems = document.querySelectorAll('.faq-item');
    
    faqItems.forEach(item => {
        const question = item.querySelector('.faq-question');
        
        question.addEventListener('click', function() {
            const isActive = item.classList.contains('active');
            
            // Close all FAQ items
            faqItems.forEach(faq => faq.classList.remove('active'));
            
            // Open clicked item if it wasn't already open
            if (!isActive) {
                item.classList.add('active');
            }
        });
    });
    
    /*==============================================
      BOOKING FORM HANDLING (SECURE VERSION)
    ==============================================*/
    const bookingForm = document.getElementById('bookingForm');
    let isSubmitting = false;
    let lastSubmitTime = 0;
    
    if (bookingForm) {
        bookingForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Rate limiting: Prevent rapid submissions (3 second cooldown)
            const now = Date.now();
            if (isSubmitting || (now - lastSubmitTime < 3000)) {
                alert('Please wait a moment before submitting again.');
                return;
            }
            
            isSubmitting = true;
            lastSubmitTime = now;
            
            // Get submit button
            const submitBtn = this.querySelector('button[type="submit"]');
            const originalText = submitBtn.textContent;
            
            // Disable button and show loading
            submitBtn.disabled = true;
            submitBtn.textContent = 'Sending...';
            
            // Get and sanitize form data
            const formData = new FormData(this);
            const data = {
                name: sanitizeInput(formData.get('name')),
                phone: sanitizeInput(formData.get('phone')),
                email: sanitizeInput(formData.get('email')),
                service: sanitizeInput(formData.get('service')),
                date: sanitizeInput(formData.get('date')),
                time: sanitizeInput(formData.get('time')),
                notes: sanitizeInput(formData.get('notes')),
                csrf_token: formData.get('csrf_token')
            };
            
            // Additional phone validation
            const phoneDigits = data.phone.replace(/\D/g, '');
            if (phoneDigits.length < 10 || phoneDigits.length > 11) {
                alert('Please enter a valid phone number (10-11 digits).');
                submitBtn.disabled = false;
                submitBtn.textContent = originalText;
                isSubmitting = false;
                return;
            }
            
            // Email validation (if provided)
            if (data.email && !data.email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) {
                alert('Please enter a valid email address.');
                submitBtn.disabled = false;
                submitBtn.textContent = originalText;
                isSubmitting = false;
                return;
            }
            
            // Send to server (or show success for now)
            // In production, this submits to booking-handler.php
            
            // For demo mode (if PHP not set up yet), show alert
            // Comment this out when PHP backend is active:
            /*
            setTimeout(() => {
                alert('Thank you for your booking request! We\'ll call you within 24 hours to confirm your appointment.');
                this.reset();
                
                // Reset button state
                submitBtn.disabled = false;
                submitBtn.textContent = originalText;
                isSubmitting = false;
                
                // Regenerate CSRF token after submission
                const newToken = generateCSRFToken();
                csrfTokenField.value = newToken;
                sessionStorage.setItem('csrf_token', newToken);
            }, 1000);
            */
            
            // Uncomment this when PHP backend is ready:
            fetch('booking-handler-twilio.php', {
                method: 'POST',
                body: formData,
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                }
            })
            .then(response => response.json())
            .then(result => {
                if (result.success) {
                    alert('Thank you! Your booking request has been received. We\'ll contact you shortly.');
                    this.reset();
                    
                    // Regenerate CSRF token
                    const newToken = generateCSRFToken();
                    csrfTokenField.value = newToken;
                    sessionStorage.setItem('csrf_token', newToken);
                } else {
                    alert('Error: ' + (result.message || 'Something went wrong. Please try again or call us.'));
                }
            })
            .catch(error => {
                alert('Network error. Please check your connection and try again, or call us directly.');
                console.error('Form submission error:', error);
            })
            .finally(() => {
                submitBtn.disabled = false;
                submitBtn.textContent = originalText;
                isSubmitting = false;
            });
        });
        
        // Set minimum date to today
        const dateInput = document.getElementById('date');
        if (dateInput) {
            const today = new Date().toISOString().split('T')[0];
            dateInput.setAttribute('min', today);
        }
    }
    
    /*==============================================
      SCROLL REVEAL ANIMATIONS
    ==============================================*/
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);
    
    // Observe service cards, review cards, etc.
    const animatedElements = document.querySelectorAll('.service-card, .review-card, .gallery-item');
    
    animatedElements.forEach((el, index) => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(30px)';
        el.style.transition = `all 0.6s ease ${index * 0.1}s`;
        observer.observe(el);
    });
    
    /*==============================================
      ACTIVE NAV LINK ON SCROLL
    ==============================================*/
    const sections = document.querySelectorAll('section[id]');
    const navLinks = document.querySelectorAll('.nav-link');
    
    window.addEventListener('scroll', function() {
        let current = '';
        
        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            const sectionHeight = section.clientHeight;
            
            if (window.pageYOffset >= sectionTop - 200) {
                current = section.getAttribute('id');
            }
        });
        
        navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href') === '#' + current) {
                link.classList.add('active');
            }
        });
    });
    
    /*==============================================
      FLOATING ACTION BUTTONS - SHOW ON SCROLL
    ==============================================*/
    const floatingActions = document.querySelector('.floating-actions');
    
    if (floatingActions) {
        window.addEventListener('scroll', function() {
            if (window.pageYOffset > 300) {
                floatingActions.style.opacity = '1';
                floatingActions.style.transform = 'translateY(0)';
            } else {
                floatingActions.style.opacity = '0';
                floatingActions.style.transform = 'translateY(20px)';
            }
        });
        
        // Initial state
        floatingActions.style.opacity = '0';
        floatingActions.style.transform = 'translateY(20px)';
        floatingActions.style.transition = 'all 0.3s ease';
    }
    
    /*==============================================
      LAZY LOADING FOR IMAGES
    ==============================================*/
    if ('IntersectionObserver' in window) {
        const imageObserver = new IntersectionObserver(function(entries, observer) {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    if (img.dataset.src) {
                        img.src = img.dataset.src;
                        img.removeAttribute('data-src');
                    }
                    img.classList.add('loaded');
                    imageObserver.unobserve(img);
                }
            });
        }, { rootMargin: '50px' });
        
        document.querySelectorAll('img[loading="lazy"]').forEach(img => {
            imageObserver.observe(img);
        });
    }
    
    /*==============================================
      PREVENT FLASH OF UNSTYLED CONTENT
    ==============================================*/
    document.body.style.opacity = '0';
    window.addEventListener('load', function() {
        document.body.style.transition = 'opacity 0.3s ease';
        document.body.style.opacity = '1';
    });
    
    /*==============================================
      PERFORMANCE - DEBOUNCE RESIZE EVENTS
    ==============================================*/
    function debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }
    
    const handleResize = debounce(function() {
        // Close mobile menu on resize to desktop
        if (window.innerWidth > 768 && mobileOverlay.classList.contains('active')) {
            closeMobileMenu();
        }
    }, 250);
    
    window.addEventListener('resize', handleResize);
    
    /*==============================================
      CONSOLE BRANDING
    ==============================================*/
    console.log('%c🎨 Barrie Braids Salon', 'font-size: 24px; font-weight: bold; color: #D4A574;');
    console.log('%c✨ Modern Website Design', 'font-size: 16px; color: #2C3E50;');
    console.log('%cBook your appointment: (705) 881-3082', 'font-size: 14px; color: #718096;');
});

/*==============================================
  UTILITY FUNCTIONS
==============================================*/

// Check if element is in viewport
function isInViewport(element) {
    const rect = element.getBoundingClientRect();
    return (
        rect.top >= 0 &&
        rect.left >= 0 &&
        rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
        rect.right <= (window.innerWidth || document.documentElement.clientWidth)
    );
}

// Get current day for business hours
function getCurrentDay() {
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    return days[new Date().getDay()];
}

// Format phone number
function formatPhoneNumber(phone) {
    const cleaned = ('' + phone).replace(/\D/g, '');
    const match = cleaned.match(/^(\d{3})(\d{3})(\d{4})$/);
    if (match) {
        return '(' + match[1] + ') ' + match[2] + '-' + match[3];
    }
    return phone;
}
